package com.perisic.beds.rmiserver;
/**
 * Can ability to start server stop server, select winner, change database values and change admin credentials
 * 
 * @author Tharaka Wasantha
 *
 */

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import com.perisic.beds.barChart.graph;
import com.perisic.beds.gui.Analysis;
//import com.perisic.beds.gui.Analysis;
import com.perisic.beds.gui.ManageQuestions;
import com.perisic.beds.gui.SelectWinner;
import com.perisic.beds.gui.View_users;
import com.perisic.beds.predefinemethods.predefineMethods;
import com.perisic.beds.rmiinterface.RemoteQuestions;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.RemoteServer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

// TODO: Auto-generated Javadoc
/**
 * The Class StartServerInterface.
 *
 * @author Tharaka Wasantha
 */
public class StartServerInterface extends JFrame {

	/** The content pane. */
	private JPanel contentPane;
	 
 	/** The tm. */
 	Timer tm;
	 
 	/** The i. */
 	int i = 0;
	 
 	/** The j. */
 	int j =0;
//Main method of the class
	/**
 * The main method.
 *
 * @param args the arguments
 */
	public static void main(String[] args) {
       
		
		try {
			boolean result=predefineMethods.adminPasswordVerification(predefineMethods.getAdminPassword());
			
			if(true) {
				System.out.println("Password Correct");
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							StartServerInterface frame = new StartServerInterface();
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}else {
				JOptionPane.showMessageDialog(null,"Password Incorrect");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 *
	 * @throws RemoteException the remote exception
	 */
	/**
	 * @throws RemoteException
	 */
	public StartServerInterface() throws RemoteException {
		
		Registry reg = LocateRegistry.createRegistry(1301); 
		
		Border emptyBorder = BorderFactory.createEmptyBorder();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 883, 550);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(128,19,54));
		panel.setBounds(0, 0, 883, 55);
		contentPane.add(panel);	
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\Tharaka\\Desktop\\img\\logo-mini.png"));
		label.setBounds(20,0,300,65);
		panel.add(label);
		
		// EXIT-Button implementation
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				System.exit(0);
			}
		});
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\Tharaka\\Desktop\\img\\icons8_Delete_25px.png"));
		lblNewLabel_2.setBounds(820, 5, 40, 62);
		panel.add(lblNewLabel_2);			
		//
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(81,10,50));
		panel_1.setBounds(0, 56, 221, 550);
		contentPane.add(panel_1);
		
		JLabel lblServer = new JLabel("SERVER");
		lblServer.setForeground(Color.WHITE);
		lblServer.setFont(new Font("Calibri", Font.BOLD, 15));
		lblServer.setBounds(12, 52, 74, 36);
		panel_1.add(lblServer);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBackground(new Color(45,20,44));
		panel_2.setBounds(218, 56, 665, 550);
		contentPane.add(panel_2);
		
		
		JLabel lblWelcomeToServer = new JLabel("WELCOME TO SERVER MANAGER");
		lblWelcomeToServer.setForeground(Color.WHITE);
		lblWelcomeToServer.setFont(new Font("Consolas", Font.BOLD, 19));
		lblWelcomeToServer.setBounds(205, 13, 267, 16);
		panel_2.add(lblWelcomeToServer);
		
		// got ahead
		JLabel status = new JLabel("Status");
		status.setForeground(Color.WHITE);
		status.setFont(new Font("Consolas", Font.ITALIC, 14));
		status.setBounds(30, 50, 500, 80);
		panel_2.add(status);
		
		JLabel timecount = new JLabel("Server Run Time:");
		timecount.setForeground(Color.WHITE);
		timecount.setFont(new Font("Consolas", Font.BOLD, 16));
		timecount.setBounds(45, 400, 200, 80);
		panel_2.add(timecount);
				
		  JLabel label34 = new JLabel("");
		  label34.setForeground(Color.WHITE);
		  label34.setFont(new Font("Tahoma", Font.BOLD, 14));
		  label34.setBounds(200, 400, 200, 80);
		  panel_2.add(label34);
		  
		  JLabel label35 = new JLabel("");
		  label35.setForeground(Color.WHITE);
		  label35.setFont(new Font("Tahoma", Font.BOLD, 14));
		  label35.setBounds(240, 400, 200, 80);
		  panel_2.add(label35);
		  
		//STOP
		
		JLabel serverStartLabel = new JLabel("Attempting to start the Question Server...");
		serverStartLabel.setFont(new Font("Consolas", Font.PLAIN, 17));
		serverStartLabel.setForeground(new Color(35, 180, 157));				 //------------------Implement Color as a RGB header
		serverStartLabel.setBounds(12, 120, 328, 16);
		panel_2.add(serverStartLabel);
		
		
		JLabel line = new JLabel("");									// Server-Machine-Image implementation
		line.setIcon(new ImageIcon("C:\\Users\\Tharaka\\Desktop\\img\\ezgif.com-rotate.gif"));
		line.setBounds(450,-40,350,80);
		panel_2.add(line);
		
		JLabel errorStatus = new JLabel(" ");
		errorStatus.setForeground(new Color(255,255,255));
		errorStatus.setFont(new Font("Consolas", Font.PLAIN, 17)); 
		errorStatus.setBounds(8, 91, 641, 27);
		panel_2.add(errorStatus);
		serverStartLabel.setVisible(false);
		
//Stop Server button implementation
		JButton btnStopServer = new JButton("Stop Server");
		btnStopServer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tm.stop();
				serverStartLabel.setVisible(true);
				timecount.setVisible(true);
				try {
				//	RemoteQuestions questions = new QuestionServerImplementation();
				//	Registry reg = LocateRegistry.createRegistry(1702);
					
					try {
						reg.unbind("ABCServer");
						errorStatus.setText("Remove rmi entry");
						errorStatus.setBounds(12, 150, 500, 16);

					} catch (AccessException | NotBoundException ex) {
		                Logger.getLogger(RemoteServer.class.getName()).log(Level.SEVERE, null, ex);
		            }

				} catch (RemoteException e) {
					String errormessage="An error occured: "+e.toString();
					errorStatus.setText(errormessage);
					
					e.printStackTrace();
				} 
				
			}
		});
		btnStopServer.setBorder(emptyBorder);
		btnStopServer.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnStopServer.setBackground(new Color(255, 0, 0));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnStopServer.setBackground(new Color(238,69,64));
			}
		});
		btnStopServer.setForeground(Color.WHITE);
		btnStopServer.setFont(new Font("Century Gothic", Font.PLAIN, 16));
		btnStopServer.setBackground(new Color(238,69,64));
		btnStopServer.setBounds(12, 124, 197, 42);
		panel_1.add(btnStopServer);
		
		JButton btnStartServer = new JButton("Start Server");
		btnStartServer.setBorder(emptyBorder);
		btnStartServer.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnStartServer.setBackground(new Color(0, 177, 157));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnStartServer.setBackground(new Color(238,69,64));
			}
		});

//Start Server button implementation
		btnStartServer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tm.start();

				serverStartLabel.setVisible(true);
				try {
					RemoteQuestions questions = new QuestionServerImplementation();
				//	Registry reg = LocateRegistry.createRegistry(1702);
					try {
						reg.rebind("ABCServer",questions);
						errorStatus.setText("Service started. Welcome to the RMI Question Service!");
						errorStatus.setBounds(12, 150, 500, 16);
						
					} catch (AccessException ex) {
		                Logger.getLogger(RemoteServer.class.getName()).log(Level.SEVERE, null, ex);
		            }

				} catch (Exception e) {
					String errormessage="An error occured: "+e.toString();
					
					errorStatus.setText(errormessage);
					e.printStackTrace();
				} 
				
			}
		});
		btnStartServer.setForeground(Color.WHITE);
		btnStartServer.setFont(new Font("Century Gothic", Font.PLAIN, 16));
		btnStartServer.setBackground(new Color(238,69,64));
		btnStartServer.setBounds(12, 80, 197, 42);
		panel_1.add(btnStartServer);
		
		JLabel lblDatabase = new JLabel("DATABASE");
		lblDatabase.setForeground(Color.WHITE);
		lblDatabase.setFont(new Font("Calibri", Font.BOLD, 15));
		lblDatabase.setBounds(12, 185, 74, 36);
		panel_1.add(lblDatabase);
		
		//Server timeout count
		 tm = new Timer(1000, new ActionListener() {
			   
			   @Override
			   public void actionPerformed(ActionEvent e) {
			    //((input % 86400 ) % 3600 ) / 60
			    label34.setText(Integer.toString((i+1%3600)/60));
			    i++;
			    label35.setText(Integer.toString((j+1)%86400));
			    j++;//--------------------------------------------------------------------------------------------------------
			    
			   }
			  });

		 //end time count
		 
//Edit database button implementation
		JButton btnEditDatabaseValues = new JButton("Handle Questions");
		btnEditDatabaseValues.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					ManageQuestions m1= new ManageQuestions();
					m1.setVisible(true);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		btnEditDatabaseValues.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnEditDatabaseValues.setBackground(new Color(102,51,0));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnEditDatabaseValues.setBackground(new Color(238,69,64));
			}
		});
		btnEditDatabaseValues.setForeground(Color.WHITE);
		btnEditDatabaseValues.setFont(new Font("Century Gothic", Font.PLAIN, 16));
		btnEditDatabaseValues.setBackground(new Color(238,69,64));
		btnEditDatabaseValues.setBounds(12, 214, 197, 42);
		panel_1.add(btnEditDatabaseValues);
		
		JLabel lblOther = new JLabel("OTHER");
		lblOther.setForeground(Color.WHITE);
		lblOther.setFont(new Font("Calibri", Font.BOLD, 15));
		lblOther.setBounds(12, 281, 74, 36);
		panel_1.add(lblOther);
		
		
//-------------------------------------------------------------------------------------------------------------------------//
//View Clients button implementation
				JButton btnViewClientDetails = new JButton("View Clients");
				btnViewClientDetails.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						try {
							View_users m1= new View_users();
							m1.setVisible(true);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}			
					}
				});
				btnViewClientDetails.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseEntered(MouseEvent arg0) {
						btnViewClientDetails.setBackground(new Color(102,51,0));
					}
					@Override
					public void mouseExited(MouseEvent e) {
						btnViewClientDetails.setBackground(new Color(238,69,64));
					}
				});
	
				btnViewClientDetails.setForeground(Color.WHITE);
				btnViewClientDetails.setFont(new Font("Century Gothic", Font.PLAIN, 16));
				btnViewClientDetails.setBackground(new Color(238,69,64));
				btnViewClientDetails.setBounds(12, 310, 197, 42); //12, 355, 197, 42    //12, 400, 197, 42   //12, 445, 197, 42 
				panel_1.add(btnViewClientDetails);
				
//Data Analysis button implementation   =?

				//
				JButton btnDataAnalysis1 = new JButton("View Graph");
				btnDataAnalysis1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						try {
							 graph a1 = new graph();
							a1.setVisible(true);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						
			
					}
				});
				btnDataAnalysis1.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseEntered(MouseEvent arg0) {
						btnDataAnalysis1.setBackground(new Color(102,51,0));
					}
					@Override
					public void mouseExited(MouseEvent e) {
						btnDataAnalysis1.setBackground(new Color(238,69,64));
					}
				});
	
				btnDataAnalysis1.setForeground(Color.WHITE);
				btnDataAnalysis1.setFont(new Font("Century Gothic", Font.PLAIN, 16));
				btnDataAnalysis1.setBackground(new Color(238,69,64));
				btnDataAnalysis1.setBounds(12, 355, 197, 42); 
				panel_1.add(btnDataAnalysis1);


//Select winner button implementation
		JButton btnSelectWinner = new JButton("Select Winner");
		btnSelectWinner.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SelectWinner s1;
				try {
					s1 = new SelectWinner();
					s1.setVisible(true);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		btnSelectWinner.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnSelectWinner.setBackground(new Color(102,51,0));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnSelectWinner.setBackground(new Color(238,69,64));
			}
		});
		btnSelectWinner.setForeground(Color.WHITE);
		btnSelectWinner.setFont(new Font("Century Gothic", Font.PLAIN, 16));
		btnSelectWinner.setBackground(new Color(238,69,64));
		btnSelectWinner.setBounds(12, 400, 197, 42 );
		panel_1.add(btnSelectWinner);

//Change admin password button implementation
		JButton btnChangePassword = new JButton("Change Password");
		btnChangePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String password = null;
					String reEnterPass = null;
					boolean result = predefineMethods.adminPasswordVerification(predefineMethods.getAdminPassword());
					int resultt = 123456;
					if(resultt ==123456) {
						System.out.println("Password Correct");
						
						JPasswordField pf = new JPasswordField();
						int okCxl = JOptionPane.showConfirmDialog(null, pf, "Enter New Password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

						if (okCxl == JOptionPane.OK_OPTION) {
						  password = new String(pf.getPassword());
						}
						
						JPasswordField pf1 = new JPasswordField();
						int okCxl1 = JOptionPane.showConfirmDialog(null, pf1, "Renter Password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

						if (okCxl1 == JOptionPane.OK_OPTION) {
							reEnterPass = new String(pf1.getPassword());
						}
						
						if(password.equals(reEnterPass)) {
							predefineMethods.setAdminPassword(password);
							JOptionPane.showMessageDialog(null,"Admin Password Successfully changed");
						}else
						{
							JOptionPane.showMessageDialog(null,"Passwords not match, Try Again");
						}

					}else {
						JOptionPane.showMessageDialog(null,"Password Incorrect");

					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btnChangePassword.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnChangePassword.setBackground(new Color(102,51,0));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnChangePassword.setBackground(new Color(238,69,64));
			}
		});
		btnChangePassword.setForeground(Color.WHITE);
		btnChangePassword.setFont(new Font("Century Gothic", Font.PLAIN, 16));
		btnChangePassword.setBackground(new Color(238,69,64));
		btnChangePassword.setBounds(12, 445, 197, 42 );  //12, 400, 197, 42
		panel_1.add(btnChangePassword);
		

				
		//Undecorated
				setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
				setLocationRelativeTo(null);
				setUndecorated(true);
				setVisible(true);
	}
	
    /**
     * Label 1 mouse clicked.
     *
     * @param evt the evt
     */
    private void label1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked

        this.dispose();
    }
}
