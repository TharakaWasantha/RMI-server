package com.perisic.beds.others;
/**
 * Serializable UserDetails class
 * 
 * @author Tharaka Wasantha
 *
 */

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class UserDetails.
 */
public class UserDetails implements Serializable {
	
	/** The user nic. */
	private String user_nic;
	
	/** The user firstname. */
	private String user_firstname;
	
	/** The user lastname. */
	private String user_lastname;
	
	/** The user fullname. */
	private String user_fullname=user_firstname+" "+user_lastname;
	
	/** The user address. */
	private String user_address;
	
	/** The user phone no. */
	private int user_phoneNo;
	
	/** The user email. */
	private String user_email;
	
	/** The user feedback. */
	private String user_feedback;
	
	/** The user bill no. */
	private long user_billNo;
	
	/** The user type. */
	private String user_type;
	
//Getters and Setters 
	/**
 * Gets the user nic.
 *
 * @return the user nic
 */
	public String getUser_nic() {
		return user_nic;
	}
	
	/**
	 * Sets the user nic.
	 *
	 * @param user_nic the new user nic
	 */
	public void setUser_nic(String user_nic) {
		this.user_nic = user_nic;
	}
	
	/**
	 * Gets the user firstname.
	 *
	 * @return the user firstname
	 */
	public String getUser_firstname() {
		return user_firstname;
	}
	
	/**
	 * Sets the user firstname.
	 *
	 * @param user_firstname the new user firstname
	 */
	public void setUser_firstname(String user_firstname) {
		this.user_firstname = user_firstname;
	}
	
	/**
	 * Gets the user lastname.
	 *
	 * @return the user lastname
	 */
	public String getUser_lastname() {
		return user_lastname;
	}
	
	/**
	 * Sets the user lastname.
	 *
	 * @param user_lastname the new user lastname
	 */
	public void setUser_lastname(String user_lastname) {
		this.user_lastname = user_lastname;
	}
	
	/**
	 * Gets the user fullname.
	 *
	 * @return the user fullname
	 */
	public String getUser_fullname() {
		return user_fullname;
	}
	
	/**
	 * Sets the user fullname.
	 *
	 * @param user_fullname the new user fullname
	 */
	public void setUser_fullname(String user_fullname) {
		this.user_fullname = user_fullname;
	}
	
	/**
	 * Gets the user address.
	 *
	 * @return the user address
	 */
	public String getUser_address() {
		return user_address;
	}
	
	/**
	 * Sets the user address.
	 *
	 * @param user_address the new user address
	 */
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	
	/**
	 * Gets the user phone no.
	 *
	 * @return the user phone no
	 */
	public int getUser_phoneNo() {
		return user_phoneNo;
	}
	
	/**
	 * Sets the user phone no.
	 *
	 * @param user_phoneNo the new user phone no
	 */
	public void setUser_phoneNo(int user_phoneNo) {
		this.user_phoneNo = user_phoneNo;
	}
	
	/**
	 * Gets the user email.
	 *
	 * @return the user email
	 */
	public String getUser_email() {
		return user_email;
	}
	
	/**
	 * Sets the user email.
	 *
	 * @param user_email the new user email
	 */
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	
	/**
	 * Gets the user feedback.
	 *
	 * @return the user feedback
	 */
	public String getUser_feedback() {
		return user_feedback;
	}
	
	/**
	 * Sets the user feedback.
	 *
	 * @param user_feedback the new user feedback
	 */
	public void setUser_feedback(String user_feedback) {
		this.user_feedback = user_feedback;
	}
	
	/**
	 * Gets the user bill no.
	 *
	 * @return the user bill no
	 */
	public long getUser_billNo() {
		return user_billNo;
	}
	
	/**
	 * Sets the user bill no.
	 *
	 * @param user_billNo the new user bill no
	 */
	public void setUser_billNo(long user_billNo) {
		this.user_billNo = user_billNo;
	}
	
	/**
	 * Gets the user type.
	 *
	 * @return the user type
	 */
	public String getUser_type() {
		return user_type;
	}
	
	/**
	 * Sets the user type.
	 *
	 * @param user_type the new user type
	 */
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}

	
	
}
