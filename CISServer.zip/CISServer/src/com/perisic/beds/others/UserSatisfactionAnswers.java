package com.perisic.beds.others;
/**
 * Serializable UserSatisfactionAnswers class
 * 
 * @author Tharaka Wasantha
 *
 */

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class UserSatisfactionAnswers.
 */
public class UserSatisfactionAnswers implements Serializable{
	
	/** The nic. */
	private String nic;
	
	/** The question 0. */
	private String question_0;
	
	/** The question 1. */
	private String question_1;
	
	/** The question 2. */
	private String question_2;
	
	/** The question 3. */
	private String question_3;
	
	/** The question 4. */
	private String question_4;
	
	/** The question 5. */
	private String question_5;
	
	/** The question 6. */
	private String question_6;
	
	/** The question 7. */
	private String question_7;
	
	/** The question 8. */
	private String question_8;
	
	/** The question 9. */
	private String question_9;
	
	/** The question 11. */
	private String question_11;
	
//Getters and Setters
	/**
 * Gets the nic.
 *
 * @return the nic
 */
	public String getNic() {
		return nic;
	}
	
	/**
	 * Sets the nic.
	 *
	 * @param nic the new nic
	 */
	public void setNic(String nic) {
		this.nic = nic;
	}
	
	/**
	 * Gets the question 0.
	 *
	 * @return the question 0
	 */
	public String getQuestion_0() {
		return question_0;
	}
	
	/**
	 * Sets the question 0.
	 *
	 * @param question_0 the new question 0
	 */
	public void setQuestion_0(String question_0) {
		this.question_0 = question_0;
	}
	
	/**
	 * Gets the question 1.
	 *
	 * @return the question 1
	 */
	public String getQuestion_1() {
		return question_1;
	}
	
	/**
	 * Sets the question 1.
	 *
	 * @param question_1 the new question 1
	 */
	public void setQuestion_1(String question_1) {
		this.question_1 = question_1;
	}
	
	/**
	 * Gets the question 2.
	 *
	 * @return the question 2
	 */
	public String getQuestion_2() {
		return question_2;
	}
	
	/**
	 * Sets the question 2.
	 *
	 * @param question_2 the new question 2
	 */
	public void setQuestion_2(String question_2) {
		this.question_2 = question_2;
	}
	
	/**
	 * Gets the question 3.
	 *
	 * @return the question 3
	 */
	public String getQuestion_3() {
		return question_3;
	}
	
	/**
	 * Sets the question 3.
	 *
	 * @param question_3 the new question 3
	 */
	public void setQuestion_3(String question_3) {
		this.question_3 = question_3;
	}
	
	/**
	 * Gets the question 4.
	 *
	 * @return the question 4
	 */
	public String getQuestion_4() {
		return question_4;
	}
	
	/**
	 * Sets the question 4.
	 *
	 * @param question_4 the new question 4
	 */
	public void setQuestion_4(String question_4) {
		this.question_4 = question_4;
	}
	
	/**
	 * Gets the question 5.
	 *
	 * @return the question 5
	 */
	public String getQuestion_5() {
		return question_5;
	}
	
	/**
	 * Sets the question 5.
	 *
	 * @param question_5 the new question 5
	 */
	public void setQuestion_5(String question_5) {
		this.question_5 = question_5;
	}
	
	/**
	 * Gets the question 6.
	 *
	 * @return the question 6
	 */
	public String getQuestion_6() {
		return question_6;
	}
	
	/**
	 * Sets the question 6.
	 *
	 * @param question_6 the new question 6
	 */
	public void setQuestion_6(String question_6) {
		this.question_6 = question_6;
	}
	
	/**
	 * Gets the question 7.
	 *
	 * @return the question 7
	 */
	public String getQuestion_7() {
		return question_7;
	}
	
	/**
	 * Sets the question 7.
	 *
	 * @param question_7 the new question 7
	 */
	public void setQuestion_7(String question_7) {
		this.question_7 = question_7;
	}
	
	/**
	 * Gets the question 8.
	 *
	 * @return the question 8
	 */
	public String getQuestion_8() {
		return question_8;
	}
	
	/**
	 * Sets the question 8.
	 *
	 * @param question_8 the new question 8
	 */
	public void setQuestion_8(String question_8) {
		this.question_8 = question_8;
	}
	
	/**
	 * Gets the question 9.
	 *
	 * @return the question 9
	 */
	public String getQuestion_9() {
		return question_9;
	}
	
	/**
	 * Sets the question 9.
	 *
	 * @param question_9 the new question 9
	 */
	public void setQuestion_9(String question_9) {
		this.question_9 = question_9;
	}
	
	/**
	 * Gets the question 11.
	 *
	 * @return the question 11
	 */
	public String getQuestion_11() {
		return question_11;
	}
	
	/**
	 * Sets the question 11.
	 *
	 * @param question_11 the new question 11
	 */
	public void setQuestion_11(String question_11) {
		this.question_11 = question_11;
	}
	
	
}
