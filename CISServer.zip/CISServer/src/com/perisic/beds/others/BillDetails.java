package com.perisic.beds.others;
/**
 * Serializable BillDetails class
 * 
 * @author Tharaka Wasantha
 *
 */

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class BillDetails.
 */
public class BillDetails implements Serializable{
	
	/** The bill no. */
	private String billNo;
	
	/** The branch code. */
	private String branchCode;
	
	/** The billcost. */
	private double billcost;
	
	/** The purchased date. */
	private String purchasedDate;
	
	/** The purchased time. */
	private String purchasedTime;
	
/**
 * Gets the bill no.
 *
 * @return the bill no
 */
//Getters and setters
	public String getBillNo() {
		return billNo;
	}
	
	/**
	 * Sets the bill no.
	 *
	 * @param billNo the new bill no
	 */
	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}
	
	/**
	 * Gets the branch code.
	 *
	 * @return the branch code
	 */
	public String getBranchCode() {
		return branchCode;
	}
	
	/**
	 * Sets the branch code.
	 *
	 * @param branchCode the new branch code
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	
	/**
	 * Gets the billcost.
	 *
	 * @return the billcost
	 */
	public double getBillcost() {
		return billcost;
	}
	
	/**
	 * Sets the billcost.
	 *
	 * @param billcost the new billcost
	 */
	public void setBillcost(double billcost) {
		this.billcost = billcost;
	}
	
	/**
	 * Gets the purchased date.
	 *
	 * @return the purchased date
	 */
	public String getPurchasedDate() {
		return purchasedDate;
	}
	
	/**
	 * Sets the purchased date.
	 *
	 * @param purchasedDate the new purchased date
	 */
	public void setPurchasedDate(String purchasedDate) {
		this.purchasedDate = purchasedDate;
	}
	
	/**
	 * Gets the purchased time.
	 *
	 * @return the purchased time
	 */
	public String getPurchasedTime() {
		return purchasedTime;
	}
	
	/**
	 * Sets the purchased time.
	 *
	 * @param purchasedTime the new purchased time
	 */
	public void setPurchasedTime(String purchasedTime) {
		this.purchasedTime = purchasedTime;
	}
	
	
}
