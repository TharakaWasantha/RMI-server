package com.perisic.beds.others;
// TODO: Auto-generated Javadoc
/**
 * MyQuestion class interact with DB questions.
 * 
 * @author Tharaka Wasantha
 *
 */

/**
 * @author Tharaka Wasantha
 *
 */
public class MyQuestion {
	
	/** The quiz ID. */
	private int quizID;
	
	/** The quiz. */
	private String quiz;
	
	/** The answer ID. */
	private int answerID;
	
	/**
	 * Gets the quiz ID.
	 *
	 * @return the quiz ID
	 */
	public int getQuizID() {
		return quizID;
	}
	
	/**
	 * Sets the quiz ID.
	 *
	 * @param quizID the new quiz ID
	 */
	public void setQuizID(int quizID) {
		this.quizID = quizID;
	}
	
	/**
	 * Gets the quiz.
	 *
	 * @return the quiz
	 */
	public String getQuiz() {
		return quiz;
	}
	
	/**
	 * Sets the quiz.
	 *
	 * @param quiz the new quiz
	 */
	public void setQuiz(String quiz) {
		this.quiz = quiz;
	}
	
	/**
	 * Gets the answer ID.
	 *
	 * @return the answer ID
	 */
	public int getAnswerID() {
		return answerID;
	}
	
	/**
	 * Sets the answer ID.
	 *
	 * @param answerID the new answer ID
	 */
	public void setAnswerID(int answerID) {
		this.answerID = answerID;
	}
	
}
