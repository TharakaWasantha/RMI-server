package com.perisic.beds.gui;
import java.awt.BorderLayout;

import java.awt.BorderLayout;
import java.awt.Color;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.Color;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
//

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

import com.perisic.beds.connection.DBconnection;

import net.proteanit.sql.DbUtils;

// TODO: Auto-generated Javadoc
/**
 * The Class Analysis.
 */
public class Analysis extends javax.swing.JFrame {

    /**
     * Instantiates a new analysis.
     */
    public Analysis()  {
    	
    	String answer_count;
        String[] arr = new String[10];
        Vector v = new Vector();
        
        int nu = 0 , ag = 0 ,di = 0 ,  kk = 0, ww= 0, qq= 0, rr= 0, yy= 0;
       int count= 0;
       
        
        try {
            //Getting data from database
            ResultSet rs = DBconnection.getData("SELECT COUNT(question_10) AS C1 FROM satisficationtable");
            while(rs.next()) {                
               answer_count= (rs.getString("C1"));
                  
               count = Integer.parseInt(answer_count);
               System.out.println(count);//testing
            }
          
             ResultSet rs1 = DBconnection.getData("SELECT question_10 FROM `satisficationtable`;");
             while(rs1.next()){
                 
                     v.add(rs1.getString("question_10"));
                    
                                    
             }
            
            Enumeration vEnum = v.elements();
            while(vEnum.hasMoreElements()){
            System.out.print(vEnum.nextElement() + " ");
            
                if(vEnum.nextElement() == "Neutral"){
                    nu++;
                } else if(vEnum.nextElement() == "Agree"){
                    ag++;
                }else if(vEnum.nextElement() == "Disagree"){
                    di++;
                }
                else if(vEnum.nextElement() == "May be"){
                    kk++;
                }
                
	            else if(vEnum.nextElement() == "Engage"){
	                ww++;
	            }
	            else if(vEnum.nextElement() == "No Idea"){
	                qq++;
	            }
	            else if(vEnum.nextElement() == "Sometime"){
	                rr++;
	            }
	            else if(vEnum.nextElement() == "Never"){
	                yy++;
	            }
                
                
            }
            
            System.out.println(nu +" "+ag +" "+di +" "+kk);
            
        } catch (Exception ex) {
            Logger.getLogger(Analysis.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        
        
        
        DefaultCategoryDataset dod = new DefaultCategoryDataset();
        dod.setValue(50, "Count", "Agree");
        dod.setValue(20, "Count", "Disagree");
        dod.setValue(30, "Count", "Neutral");
        dod.setValue(60, "Count", "May be");
        dod.setValue(45, "Count", "Engage");
        dod.setValue(10, "Count", "No Idea");
        dod.setValue(70, "Count", "Sometime");
        dod.setValue(45, "Count", "Never");
       
        
        JFreeChart jchart = ChartFactory.createBarChart("Service representatives are well trained?", "Answer", "Customers %", dod, PlotOrientation.VERTICAL, true, true, true);
        CategoryPlot plot = jchart.getCategoryPlot();
        plot.setRangeGridlinePaint(Color.black);
        
        ChartFrame chartfrm = new ChartFrame("Student Record",jchart,true);
        chartfrm.setVisible(true);
        chartfrm.setSize(800,700);
        
		//Undecorated
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setUndecorated(true);
		setVisible(true);

    		
       
    }



}
