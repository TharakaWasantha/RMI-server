package com.perisic.beds.predefinemethods;
/**
 * Contains with methods wich are interact with DB operations
 * 
 * @author Tharaka Wasantha
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.perisic.beds.connection.DBconnection;

// TODO: Auto-generated Javadoc
/**
 * The Class DBMethods.
 */
public class DBMethods {
	
/**
 * Gets the r esult set.
 *
 * @param aq the aq
 * @return the r esult set
 * @throws Exception the exception
 */
//Method to get resultSet by executing Query
    public static ResultSet getREsultSet(String aq) throws Exception {
       
        Connection conn=DBconnection.connect();
        Statement state=conn.prepareStatement(aq);
      
      return  state.executeQuery(aq);
    }
     
/**
 * Execute.
 *
 * @param aq the aq
 * @return true, if successful
 * @throws Exception the exception
 */
//Method to execute Query
    public static boolean execute(String aq) throws Exception {
       
        Connection conn=DBconnection.connect();
        Statement state=conn.createStatement();
      
      return  state.executeUpdate(aq)>0;
      
    }
   
/**
 * Prepare.
 *
 * @param qry the qry
 * @return the prepared statement
 * @throws Exception the exception
 */
//Method to get Prepared Statement for the query
    public static PreparedStatement prepare(String qry)throws Exception {
    	Connection conn=DBconnection.connect();
    	PreparedStatement pst=conn.prepareStatement(qry);
    	return pst;
    	
    }
}
