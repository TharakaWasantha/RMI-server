package com.perisic.beds.barChart;


import java.awt.EventQueue;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.sql.ResultSet;
import java.util.Enumeration;
import java.util.Vector;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import com.mysql.cj.protocol.Resultset;

public class graph {

    public static void main(String[] args) {
        new graph();
       
    }

    public graph() {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
            	
            	
            	String answer_count;
                String[] arr = new String[10];
                Vector v = new Vector();
                
                int nu = 0 , ag = 0 ,di = 0;
               int count= 0;
                
                
                
                
                try {
                    //Getting data from database
                    ResultSet rs = db.getData("SELECT COUNT(question_10) AS C1 FROM satisficationtable");
                    while(rs.next()) {                
                       answer_count= (rs.getString("C1"));
                          
                       count = Integer.parseInt(answer_count);
                       System.out.println(count);//testing
                    }
                  
                     ResultSet rs1 = db.getData("SELECT question_10 FROM `satisficationtable`;");
                     while(rs1.next()){
                         
                             v.add(rs1.getString("question_10"));
                            
                                            
                     }
                    System.out.println(v);
                    
                 // Creating an empty enumeration to store 
                    Enumeration enu = v.elements(); 
              
                    System.out.println("The enumeration of values are:"); 
              
                    // Displaying the Enumeration 
                    while (enu.hasMoreElements()) { 
                        System.out.println(enu.nextElement()); 
                       
                      
                        	//System.out.println(enu.nextElement().toString());
                        
                       
                    } 
                    
                } catch (Exception ex) {
                   ex.printStackTrace();
                }
            	
            	
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }

                try {
                	//Implementing Google image charts API
                	
                    String path = "https://chart.googleapis.com/chart?cht=p3&chd=t:60,25,15&chs=750x400&chl=Agree|Disagree|Nuetral";
                    System.out.println("Get Image from " + path);
                    URL url = new URL(path);
                    BufferedImage image = ImageIO.read(url);
                    System.out.println("Load image into frame...");
                    JLabel label = new JLabel(new ImageIcon(image));
                    JFrame f = new JFrame();
                    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    f.getContentPane().add(label);
                    f.pack();
                    f.setLocation(200, 200);
                    f.setVisible(true);
                } catch (Exception exp) {
                    exp.printStackTrace();
                }

            }
        });
    }

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
