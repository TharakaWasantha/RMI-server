package com.perisic.beds.rmiinterface;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Vector;
import com.perisic.beds.others.BillDetails;
import com.perisic.beds.others.UserDetails;
// TODO: Auto-generated Javadoc
/**
 * RMI interface to enable to retrieve questions from the server and to submit data
 * to the server. 
 * @author Tharaka Wasantha
 *
 */
public interface RemoteQuestions extends Remote {
	
	/**
	 * Number of questions on the server.
	 *
	 * @return the number of questions
	 * @throws RemoteException the remote exception
	 */
	public int getNumberOfQuestions() throws RemoteException; 
	
	/**
	 * Retrieve specific question from the server. 
	 *
	 * @param i number of the question.
	 * @return the Question.
	 * @throws RemoteException the remote exception
	 */
	public Question getQuestion(int i) throws RemoteException; 
	
	/**
	 * Submit the answer to the question number i.
	 *
	 * @param i question where the answer belongs to.
	 * @param answer the answer given to this question.
	 * @throws RemoteException the remote exception
	 */
	void submitAnswer(int i, String answer) throws RemoteException;  
	
	/**
	 * Returns the answers to the questions given. 
	 *
	 * @return answers to the questions.
	 * @throws RemoteException the remote exception
	 */
	public Vector<Question> getData() throws RemoteException; 
	
	//******************************************************************************************************************** My Methods
	
	
/**
	 * Gets the name.
	 *
	 * @param billNo the bill no
	 * @return the name
	 * @throws RemoteException the remote exception
	 * @throws Exception the exception
	 */
	//Abstract type Methods	
	public String getName(int billNo)throws RemoteException, Exception; 
	
	/**
	 * Validate bill no.
	 *
	 * @param billNo the bill no
	 * @return true, if successful
	 * @throws RemoteException the remote exception
	 */
	public boolean validateBillNo(long billNo)throws RemoteException;
	
	/**
	 * Gets the serialized user details.
	 *
	 * @param billNo the bill no
	 * @return the serialized user details
	 * @throws RemoteException the remote exception
	 */
	public void getSerializedUserDetails(long billNo)throws RemoteException;
	
	/**
	 * Gets the deserialized user details.
	 *
	 * @return the deserialized user details
	 * @throws Exception the exception
	 */
	public UserDetails getDeserializedUserDetails()throws Exception;
	
	/**
	 * Check registration status.
	 *
	 * @param billNo the bill no
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	public boolean checkRegistrationStatus(long billNo)throws Exception;
	
	/**
	 * Gets the wining progree.
	 *
	 * @param nic the nic
	 * @return the wining progree
	 * @throws Exception the exception
	 */
	public double getWiningProgree(int nic) throws Exception;
	
	/**
	 * Sets the client submission.
	 *
	 * @param qID the q ID
	 * @param answer the answer
	 * @param nic the nic
	 * @throws Exception the exception
	 */
	public void setClientSubmission(int qID, String answer, String nic)throws Exception;
	
	/**
	 * Creates the satisfication table column.
	 *
	 * @param nic the nic
	 * @throws Exception the exception
	 */
	public void createSatisficationTableColumn(String nic)throws Exception;
	
	/**
	 * Gets the serialized user satisfication answers.
	 *
	 * @param nic the nic
	 * @return the serialized user satisfication answers
	 * @throws RemoteException the remote exception
	 */
	public void getSerializedUserSatisficationAnswers(int nic)throws RemoteException;
	
	/**
	 * Gets the clients satisfication answers.
	 *
	 * @return the clients satisfication answers
	 * @throws Exception the exception
	 */
	public String[][] getClientsSatisficationAnswers()throws Exception;
	
	/**
	 * Sets the username and password.
	 *
	 * @param username the username
	 * @param password the password
	 * @param nic the nic
	 * @throws Exception the exception
	 */
	public void setUsernameAndPassword(String username,String password,String nic)throws Exception;
	
	/**
	 * Update registration.
	 *
	 * @param nic the nic
	 * @throws Exception the exception
	 */
	public void updateRegistration(String nic)throws Exception;
	
	/**
	 * Gets the password from username.
	 *
	 * @param username the username
	 * @return the password from username
	 * @throws Exception the exception
	 */
	public String getPasswordFromUsername(String username)throws Exception;
	
	/**
	 * Gets the answer count yes no quiz.
	 *
	 * @param quiz the quiz
	 * @param ans the ans
	 * @return the answer count yes no quiz
	 * @throws Exception the exception
	 */
	public int getAnswerCountYesNoQuiz (String quiz, String ans)throws Exception;
	
	/**
	 * Gets the bill details.
	 *
	 * @param nic the nic
	 * @return the bill details
	 * @throws Exception the exception
	 */
	public BillDetails getBillDetails(String nic)throws Exception;
	
	/**
	 * Gets the branch location.
	 *
	 * @param branchCode the branch code
	 * @return the branch location
	 * @throws Exception the exception
	 */
	public String getBranchLocation(String branchCode)throws Exception;
	
	/**
	 * Gets the employee ID from bill no.
	 *
	 * @param billNo the bill no
	 * @param empPostition the emp postition
	 * @return the employee ID from bill no
	 * @throws Exception the exception
	 */
	public String getEmployeeIDFromBillNo(String billNo, String empPostition)throws Exception;
	
	/**
	 * Gets the employee name from emp ID.
	 *
	 * @param empID the emp ID
	 * @return the employee name from emp ID
	 * @throws Exception the exception
	 */
	public String getEmployeeNameFromEmpID(String empID)throws Exception;
	
	/**
	 * Gets the user details from NIC.
	 *
	 * @param nic the nic
	 * @return the user details from NIC
	 * @throws Exception the exception
	 */
	public UserDetails getUserDetailsFromNIC(String nic)throws Exception;
	
	/**
	 * Update user.
	 *
	 * @param nic the nic
	 * @param name the name
	 * @param address the address
	 * @param phoneNo the phone no
	 * @param email the email
	 * @param feedback the feedback
	 * @throws Exception the exception
	 */
	public void updateUser(String nic, String name, String address, String phoneNo, String email, String feedback)throws Exception;
	
	/**
	 * Sets the completeness value.
	 *
	 * @param nic the new completeness value
	 * @throws Exception the exception
	 */
	public void setCompletenessValue(String nic)throws Exception;
	
	/**
	 * Gets the completeness value.
	 *
	 * @param nic the nic
	 * @return the completeness value
	 * @throws Exception the exception
	 */
	public boolean getCompletenessValue(String nic)throws Exception;
	
	/**
	 * Update winning progress value.
	 *
	 * @param Value the value
	 * @param nic the nic
	 * @throws Exception the exception
	 */
	public void updateWinningProgressValue(double Value, String nic)throws Exception;
	
	/**
	 * Bill no array.
	 *
	 * @param nic the nic
	 * @return the string[]
	 * @throws Exception the exception
	 */
	public String[] billNoArray(String nic) throws Exception;
	
	/**
	 * Gets the bill details from bill number.
	 *
	 * @param billNo the bill no
	 * @return the bill details from bill number
	 * @throws Exception the exception
	 */
	public BillDetails getBillDetailsFromBillNumber(String billNo)throws Exception;
	
	/**
	 * Gets the question score.
	 *
	 * @return the question score
	 * @throws Exception the exception
	 */
	public double getQuestionScore()throws Exception;
	
	/**
	 * Gets the salt from username.
	 *
	 * @param username the username
	 * @return the salt from username
	 * @throws Exception the exception
	 */
	public String getSaltFromUsername(String username)throws Exception;
	
	/**
	 * Verfiy salted password.
	 *
	 * @param password the password
	 * @param dbPass the db pass
	 * @param saltValue the salt value
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	public boolean verfiySaltedPassword(String password,String dbPass,String saltValue)throws Exception;
	
	/**
	 * Read selection file.
	 *
	 * @return the string
	 * @throws Exception the exception
	 */
	public String readSelectionFile()throws Exception;
		
	/**
	 * Send email.
	 *
	 * @param subject the subject
	 * @param message the message
	 * @param to the to
	 * @throws Exception the exception
	 */
	public void sendEmail(String subject, String message, String to)throws Exception;
	
	/**
	 * Gets the email.
	 *
	 * @param billNo the bill no
	 * @return the email
	 * @throws Exception the exception
	 */
	public  String getEmail(String billNo) throws Exception;
	
	/**
	 * Gets the email from username.
	 *
	 * @param username the username
	 * @return the email from username
	 * @throws Exception the exception
	 */
	public String getEmailFromUsername(String username) throws Exception;
	
	/**
	 * Reset password.
	 *
	 * @param password the password
	 * @param nic the nic
	 * @throws Exception the exception
	 */
	public void resetPassword(String password, String nic) throws Exception;
	
	/**
	 * Store winner value.
	 *
	 * @param billNumber the bill number
	 * @param winner the winner
	 * @throws Exception the exception
	 */
	public void storeWinnerValue(String billNumber, String winner)throws Exception;
	
	/**
	 * Gets the winner details.
	 *
	 * @return the winner details
	 * @throws Exception the exception
	 */
	public String[] getWinnerDetails()throws Exception;
	
}
